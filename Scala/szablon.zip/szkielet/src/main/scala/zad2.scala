import org.apache.pekko.actor.typed.scaladsl.Behaviors
import org.apache.pekko.actor.typed.*
import scala.util.Random

sealed trait Message
case class Utworz2(n: Int) extends Message
case object Generuj extends Message
case class Wynik(n: Int) extends Message

//losowanie liczb calkowitych z przedzialu od n do m
def losuj_zad2(n: Int, m: Int): Int = {
  val random = new Random()
  n + random.nextInt(m - n + 1)
}

object Nadzorca {
 def apply(): Behavior[Message] = Behaviors.receive {
    ???
 }
}

object Generator {
 def apply(): Behavior[Message] = Behaviors.receive {
    ???
 }
}


@main 
def zad2: Unit = {
   val pacjent: ActorSystem[Message] = ActorSystem(Nadzorca(), "Zadanie2")
}
