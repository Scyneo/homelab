import org.apache.pekko
import pekko.actor.*
import scala.util.Random

case class Utworz(lMagazynierow: Int)
case object Dostawa
case class Dostarcz(firma: ActorRef)
case class Przyjmujacy(magazynier: ActorRef)
case object Brak
case class Przyjmij(list: List[Int])
case class Towar(list: List[Int])

//losowanie liczb calkowitych z przedzialu od n do m
def losuj_zad1(n: Int, m: Int): Int = {
  val random = new Random()
  n + random.nextInt(m - n + 1)
}

class Firma extends Actor with ActorLogging {
  def receive: Receive = {
    ???
  }
}

class Dostawca extends Actor with ActorLogging {
  def receive: Receive = {
    ???
  }
}

class Magazynier extends Actor with ActorLogging {
  def receive: Receive = {
    ???
  }
}

@main 
def zad1: Unit = {
  val system = ActorSystem("Zadanie1")
}
