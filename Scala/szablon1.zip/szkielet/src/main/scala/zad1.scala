def leastVal[A, B](l1: List[A], l2: List[B])(op: (A, B) => Double): Double = {
	if (l1.size == 0 || l2.size == 0) throw new IllegalArgumentException
	???
}

@main def zad1: Unit = {
}
