@main def zad2: Unit = {
 val domki = io.Source
  .fromResource("domki.txt")
  .getLines.toList

 val rezerwacje = io.Source 
  .fromResource("rezerwacje.txt")
  .getLines.toList
}
